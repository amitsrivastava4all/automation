package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.brainmentors.lms.utils.Driver;

public class RightClickDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String URL = "https://the-internet.herokuapp.com/context_menu";
		 WebDriver driver = Driver.getChromeDriver();
			
			Driver.openURL(driver,URL);
			WebElement ele = driver.findElement(By.id("hot-spot"));
			Actions actions = new Actions(driver);
			actions.contextClick(ele).perform(); // R.C
			actions.click(); // L.C
			actions.doubleClick(); 
	}

}
