package com.brainmentors.lms.testing;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SecondDemo {
	@BeforeSuite
	public void one() {
		System.out.println("Suite Start....");
	}
	@BeforeTest
	public void beforeTest() {
		System.out.println("Before Test");
	}
	
	@BeforeClass
	public void beforeClass() {
		System.out.println("Before Class");
	}
	
	@BeforeMethod
	public void start() {
		System.out.println("Start");
	}
	
	void setup() {
		System.out.println("Setup....");
	}
	
	@Test(groups = {"mygroup"})
	public void testLogin() {
		System.out.println("test login");
	}
	
	@Test(groups = {"mygroup"})
	public void testGenerateToken() {
		System.out.println("test token");
	}
	
	
	
	//@Test(expectedExceptions = {NoSuchElementException.class,ElementNotVisibleException.class})
	//@Test(dependsOnMethods = {"setup"})
	@Test(dependsOnGroups = {"mygroup"},priority = 2)
	public void test2() {
		System.out.println("After Setup");
	}
	
	@Test(priority = 1)
	public void testDemo() {
		System.out.println("I am in TestDemo");
		Assert.assertEquals(100, 100);
	}
	
	@AfterMethod
	public void end() {
		System.out.println("End");
	}
	
	
	@AfterClass
	public void afterClass() {
		System.out.println("After Class");
	}
	
	@AfterTest
	public void afterTest() {
		System.out.println("After Test");
	}
	
	@AfterSuite
	public void oneend() {
		System.out.println("Suite Ends....");
	}

}
