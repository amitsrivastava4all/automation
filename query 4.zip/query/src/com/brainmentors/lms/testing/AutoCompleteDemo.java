package com.brainmentors.lms.testing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.brainmentors.lms.utils.Driver;

public class AutoCompleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String URL = "https://in.yahoo.com/?p=us";
		 WebDriver driver = Driver.getChromeDriver();
			
			Driver.openURL(driver,URL);
			driver.findElement(By.id("header-search-input")).sendKeys("BMW");
			Wait<WebDriver> wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("ul[role='listbox']")));
			WebElement ul = driver.findElement(By.cssSelector("ul[role='listbox']"));
			List<WebElement> liElements  = ul.findElements(By.tagName("li"));
			//List<WebElement> liElements = driver.findElements(By.cssSelector("ul[role='listbox']"));
			for(WebElement ele : liElements) {
				if(ele.getText().contains("cars")) {
					System.out.println(ele);
					System.out.println(" VALUE IS "+ele.getText());
					ele.click();
					break;
				}
			}
	}

}
