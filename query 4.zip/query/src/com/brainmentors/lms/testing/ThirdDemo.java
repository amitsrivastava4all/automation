package com.brainmentors.lms.testing;

import org.testng.annotations.Test;

public class ThirdDemo {

	@Test(groups = "mygroup")
	public void testFourth() {
		System.out.println("test fourth");
	}

}
