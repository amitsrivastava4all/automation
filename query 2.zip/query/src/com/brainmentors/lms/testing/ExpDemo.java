package com.brainmentors.lms.testing;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.brainmentors.lms.utils.Driver;

public class ExpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/dynamic_loading/2");
		driver.findElement(By.cssSelector("#start>button")).click();
		Wait<WebDriver> fluentWait = new FluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(5))
				.ignoring(NoSuchElementException.class);
//		FluentWait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver);
//		
//		fluentWait = fluentWait.withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofSeconds(5))
//		.ignoring(NoSuchElementException.class);
		//WebDriverWait webDriverWait = new WebDriverWait(driver, 10);
		//ExpectedConditions.elementToBeClickable(locator)
		//ExpectedConditions.textToBePresentInElementLocated(By.cssSelector("#finish>h4"), "Hello World");
		WebElement h4 = fluentWait.until(new Function<WebDriver, WebElement>(){

			@Override
			public WebElement apply(WebDriver t) {
				// TODO Auto-generated method stub
				return driver.findElement(By.id("finish"));
			}
			
		});
		//webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#finish>h4")));
		//webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#finish>h4")));
		//WebElement h4 = driver.findElement(By.cssSelector("#finish>h4"));
		System.out.println("I am Here");
		
		System.out.println(h4.getText());
		//WebElement el = driver.findElement(By.id("finish"));
		driver.close();

	}

}
