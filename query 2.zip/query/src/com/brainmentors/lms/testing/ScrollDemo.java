package com.brainmentors.lms.testing;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.brainmentors.lms.utils.Driver;

public class ScrollDemo {

	public static void main(String[] args) {
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://www.flipkart.com/");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scroll(10,document.body.scrollHeight);");
		

	}

}
