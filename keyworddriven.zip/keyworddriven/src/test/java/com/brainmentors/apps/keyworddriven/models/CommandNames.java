package com.brainmentors.apps.keyworddriven.models;

public interface CommandNames {
	String BROWSER = "browser";
	String OPEN = "open";
	String TYPE = "type";
	String CLICK = "click";
	String CLOSE = "close";
	String SIZE  ="size";
}
