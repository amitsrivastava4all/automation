package com.brainmentors.apps.keyworddriven.utils;

public interface Constants {
	String XLSPATH= "xlspath";
	String SHEET_NAME = "register";
	int COMMAND = 1;
	int TARGET = 2;
	int VALUE = 3;
}
