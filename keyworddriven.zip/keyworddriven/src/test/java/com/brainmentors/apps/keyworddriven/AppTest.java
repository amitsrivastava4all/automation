package com.brainmentors.apps.keyworddriven;

import java.io.IOException;
import java.util.List;

import com.brainmentors.apps.keyworddriven.models.CommandDTO;
import com.brainmentors.apps.keyworddriven.utils.ExcelReader;

public class AppTest{
	
	public static void main(String[] args) throws IOException {
		List<CommandDTO> commands = ExcelReader.readXLS();
		System.out.println(commands);
	}
	
}
