package com.brainmentors.apps.keyworddriven.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.brainmentors.apps.keyworddriven.models.CommandDTO;

public interface ExcelReader {

	public static List<CommandDTO> readXLS() throws IOException {
		File file = new File(ConfigReader.getValue(Constants.XLSPATH));
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		FileInputStream fs = new FileInputStream(file);
		HSSFWorkbook workBook = new HSSFWorkbook(fs);
		HSSFSheet sheet =  workBook.getSheet(Constants.SHEET_NAME);
		Iterator<Row> rows = sheet.rowIterator();
		boolean isHeading = true;
		List<CommandDTO> commands = new ArrayList<>();
		int currentCell = 0;
		try {
		while(rows.hasNext()) {
			if(isHeading) {
				rows.next();
				isHeading = false;
			}
			CommandDTO command = new CommandDTO();
			currentCell = 1;
			Row currentRow = rows.next();
			Iterator<Cell> cells = currentRow.cellIterator();
			
			while(cells.hasNext()) {
				Cell cell = cells.next();
				String val = "";
				if(cell.getCellType()==CellType.STRING) {
					val = cell.getStringCellValue();
				}
				else
				if(cell.getCellType()== CellType.NUMERIC) {
					val = String.valueOf(cell.getNumericCellValue());
				}
				if(currentCell==Constants.COMMAND) {
					command.setCommand(val);
				}
				else
				if(currentCell==Constants.TARGET) {
					command.setTarget(val);
				}
				else
				if(currentCell== Constants.VALUE) {
					command.setValue(val);
				}
				currentCell++;
				
			}
			commands.add(command);
			
		}// rows end
		}// try end
		finally {
			// resource clean up code
			if(workBook!=null) {
				workBook.close();
			}
			if(fs!=null) {
				fs.close();
			}
		}
		return commands;
	} // method ends
	
	
	
}
