package com.brainmentors.apps.keyworddriven;

import java.io.IOException;
import java.util.List;

import com.brainmentors.apps.keyworddriven.models.CommandDTO;
import com.brainmentors.apps.keyworddriven.models.CommandNames;
import com.brainmentors.apps.keyworddriven.utils.ExcelReader;

public class CommandExecutor implements CommandNames {

	
	public void execute() {
		try {
			List<CommandDTO> commands = ExcelReader.readXLS();
			for(CommandDTO command: commands) {
				if(command.getCommand().equals(BROWSER)) {
					
				}
				else
				if(command.getCommand().equals(OPEN)) {
					
				}
				else
				if(command.getCommand().equals(TYPE)) {
					
				}
				else
				if(command.getCommand().equals(CLICK)) {
					
				}
				else
				if(command.getCommand().equals(CLOSE)) {
						
					}
				else
				if(command.getCommand().equals(SIZE)) {
							
						}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
