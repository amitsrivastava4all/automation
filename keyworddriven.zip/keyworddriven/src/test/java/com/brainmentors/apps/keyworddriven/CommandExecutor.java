package com.brainmentors.apps.keyworddriven;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.Test;

import com.brainmentors.apps.keyworddriven.models.CommandDTO;
import com.brainmentors.apps.keyworddriven.models.CommandNames;
import com.brainmentors.apps.keyworddriven.utils.ExcelReader;

public class CommandExecutor implements CommandNames {
	
	public static void main(String[] args) {
		CommandExecutor ce = new CommandExecutor();
		ce.execute();
	}

	//@Test
	public void execute() {
		Command commandObject = new Command();
		try {
			List<CommandDTO> commands = ExcelReader.readXLS();
			for(CommandDTO command: commands) {
				if(command.getCommand().equals(BROWSER)) {
					commandObject.browser(command.getValue());
				}
				else
				if(command.getCommand().equals(OPEN)) {
					commandObject.open(command.getValue());
				}
				else
				if(command.getCommand().equals(TYPE)) {
					commandObject.type(command.getTarget(), command.getValue());
				}
				else
				if(command.getCommand().equals(CLICK)) {
					commandObject.sleep();
					commandObject.click(command.getTarget(), command.getValue());
				}
				else
				if(command.getCommand().equals(CLOSE)) {
						commandObject.close();
					}
				else
				if(command.getCommand().equals(SIZE)) {
							
						}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
