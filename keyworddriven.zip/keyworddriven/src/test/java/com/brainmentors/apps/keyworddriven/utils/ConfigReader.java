package com.brainmentors.apps.keyworddriven.utils;

import java.util.ResourceBundle;

public class ConfigReader {
	private static ResourceBundle resourceBundle = ResourceBundle.getBundle("config");	
	private ConfigReader() {}
	public static String getValue(String key) {
		return resourceBundle.getString(key);
	}
	
	

}
