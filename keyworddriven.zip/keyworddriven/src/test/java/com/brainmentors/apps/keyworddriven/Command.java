package com.brainmentors.apps.keyworddriven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.brainmentors.apps.keyworddriven.utils.ConfigReader;
import com.brainmentors.apps.keyworddriven.utils.Constants;

public class Command implements Constants {
	WebDriver driver;
	
	public void open(String url) {
		driver.get(url);
			
	}
	public void browser(String browserName) {
		
		if(CHROME.equals(browserName)) {
			System.setProperty("webdriver.chrome.driver", ConfigReader.getValue(CHROME_DRIVER));
			driver = new ChromeDriver();
		}
		else
		if(FIREFOX.equals(browserName))	{
			System.setProperty("webdriver.gecko.driver", ConfigReader.getValue(FIREFOX_DRIVER));
			driver = new FirefoxDriver();
		}
		
	}
	
	public void type(String target, String value) {
		WebElement element = getElement(target, value);
		element.sendKeys(value);
	}
	
	private String  split(String target, boolean selector) {
		if(selector) {
			return target.split("=")[0];
		}
		else {
			return target.split("=")[1];
		}
		
	}
	
	private WebElement getElement(String target, String value) {
		WebElement element = null; 	
		String selector = split(target, true);
		String selectorValue = split(target, false);
			if(ID.equals(selector)) {
				element = driver.findElement(By.id(selectorValue));
			}
			else
				if(NAME.equals(selector)) {
					element = driver.findElement(By.name(selectorValue));
				}	
				else
					if(CLASS.equals(selector)) {
						element = driver.findElement(By.className(selectorValue));
					}
					else
						if(XPATH.equals(selector)) {
							element = driver.findElement(By.xpath(selectorValue));
						}
			return element;
	}
	
	
	public void sleep() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void click(String target, String value) {
			WebElement element = getElement(target, value);
			element.click();
			
	}
	
public void close() {
		if(driver!=null) {
			driver.close();
		}
	}
public void size() {
	
}

}
