package com.brainmentors.apps.keyworddriven;

public class Command {
	
	public void open() {
		
	}
	public void browser() {
		
		
	}
	
	public void type() {
		
	}
	
	public void click() {
		
	}
	
public void close() {
		
	}
public void size() {
	
}

}
