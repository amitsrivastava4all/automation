package com.brainmentors.apps.keyworddriven.models;
// DTO - Data Transfer Object
public class CommandDTO {
	
	private String command;
	private String target;
	private String value;
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "CommandDTO [command=" + command + ", target=" + target + ", value=" + value + "]\n";
	}
	
	

}
