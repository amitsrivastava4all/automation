package com.brainmentors.lms.testing;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.brainmentors.lms.utils.Driver;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		List<WebElement> list = driver.findElements(By.tagName("button"));
		for(WebElement ele : list) {
			if(ele.getText().contains("Prompt")) {
				ele.click();
				Thread.sleep(2000);
				driver.switchTo().alert().sendKeys("Hello JS");
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				Thread.sleep(2000);
				//driver.switchTo().alert().accept(); // ok
				//driver.switchTo().alert().dismiss(); // cancel
				break;
			}
		}
		driver.close();
		
	}

}
