package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.brainmentors.lms.utils.Driver;

public class FirstTest {
	
	@Test
	
	public void testLogin() throws InterruptedException {
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/hovers");
		WebElement element = driver.findElement(By.cssSelector("img[alt='User Avatar']"));
		System.out.println("Sleep...");
		Thread.sleep(3000);
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
		WebElement e2 = driver.findElement(By.cssSelector(".figcaption>h5"));
		String msg = e2.getText();
		Assert.assertTrue(msg.contains("user1"));
		driver.close();
	}
	
//@Test(enabled = false)
	@Test
@Ignore
	
	public void testLogin2() throws InterruptedException {
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/hovers");
		WebElement element = driver.findElement(By.cssSelector("img[alt='User Avatar']"));
		System.out.println("Sleep...");
		Thread.sleep(3000);
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
		WebElement e2 = driver.findElement(By.cssSelector(".figcaption>h5"));
		String msg = e2.getText();
		Assert.assertTrue(msg.contains("amit"));
		driver.close();
	}

	
}
