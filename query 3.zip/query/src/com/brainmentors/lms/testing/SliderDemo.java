package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.brainmentors.lms.utils.Driver;

public class SliderDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
			String URL = "http://127.0.0.1:5500/datepickerdemo/index2.html";
	 WebDriver driver = Driver.getChromeDriver();
		
		Driver.openURL(driver,URL);
		System.out.println("Start...");
		WebElement ele2 = driver.findElement(By.cssSelector("#red > span"));
		WebElement ele = driver.findElement(By.id("myrange"));
		//Actions action  =new Actions(driver);
		Thread.sleep(4000);
		//action.dragAndDropBy(ele, 10, 0).build().perform();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('#red>span').style.left=\"60%\"");
		System.out.println("DONE....");
		//driver.close();
		

	}

}
