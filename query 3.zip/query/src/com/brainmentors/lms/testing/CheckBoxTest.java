package com.brainmentors.lms.testing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.brainmentors.lms.utils.Driver;

public class CheckBoxTest {

	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		// Load a Driver
		// Windows
		// /Users/amit/Documents/seltodaycode/chromedriver.exe
//		String path = "/Users/amit/Documents/seltodaycode/chromedriver";
//		System.setProperty("webdriver.chrome.driver", path);
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://the-internet.herokuapp.com/checkboxes");
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/checkboxes");
		List<WebElement> allCheckBox = driver.findElements(By.tagName("input"));
		int count = 0;
		Thread.sleep(5000);
		for(WebElement checkBox: allCheckBox) {
			if(checkBox.isSelected()) {
				count++;
				continue;
			}
			
			checkBox.click();
		}
		
		System.out.println("Count is "+count);
		Thread.sleep(5000);
		driver.close();
		
	}

}
