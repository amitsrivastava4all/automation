package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.brainmentors.lms.utils.Driver;

public class DropDownTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/dropdown");
		WebElement element = driver.findElement(By.id("dropdown"));
		Select dropDownSelect = new Select(element);
		//dropDownSelect.selectByVisibleText("Option 2");
		//dropDownSelect.selectByValue("2");
		dropDownSelect.selectByIndex(0);
		
	}

}
