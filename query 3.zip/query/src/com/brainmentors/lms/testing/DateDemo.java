package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.brainmentors.lms.utils.Driver;

public class DateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String URL = "http://127.0.0.1:5500/datepickerdemo/index.html";
		 WebDriver driver = Driver.getChromeDriver();
			
			Driver.openURL(driver,URL);
//			Wait<WebDriver> wait = new WebDriverWait(driver, 20);
//			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("datepicker")));
			driver.findElement(By.id("datepicker")).sendKeys("01/30/2021");

	}

}
