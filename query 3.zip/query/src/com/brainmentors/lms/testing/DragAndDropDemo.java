package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.brainmentors.lms.utils.Driver;

public class DragAndDropDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String URL = "http://demo.guru99.com/test/drag_drop.html";
		 WebDriver driver = Driver.getChromeDriver();
			
			Driver.openURL(driver,URL);
			WebElement source = driver.findElement(By.cssSelector("#credit2>a"));
			WebElement target = driver.findElement(By.cssSelector("#bank>li"));
			Actions action = new Actions(driver);
			action.dragAndDrop(source, target).build().perform();
			//action.clickAndHold(source).moveToElement(target).release().build().perform();

	}

}
