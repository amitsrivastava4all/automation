package com.brainmentors.lms.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Driver { 
	
	public static WebDriver getChromeDriver(){
		String path = "/Users/amit/Documents/seltodaycode/chromedriver";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}
	
	public static void openURL(WebDriver driver, String url) {
		driver.get(url);
	}

}
