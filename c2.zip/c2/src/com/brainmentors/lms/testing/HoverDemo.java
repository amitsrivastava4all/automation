package com.brainmentors.lms.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.brainmentors.lms.utils.Driver;

public class HoverDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/hovers");
		WebElement element = driver.findElement(By.cssSelector("img[alt='User Avatar']"));
		System.out.println("Sleep...");
		Thread.sleep(3000);
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();

	}

}
