package com.brainmentors.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Command {
	
	private static WebDriver driver;
	/**
	 * this method will load a driver
	 */
	private static void loadDriver() {
		System.setProperty(ConfigReader.getValue("drivername")
				, ConfigReader.getValue("driverpath"));
	}
	
	public static String getURL() {
		return ConfigReader.getValue("url");
	}
	public static String getConfigBrowser() {
		return ConfigReader.getValue("browser");
	}
	
	/**
	 * this method will open a browser with specified url
	 */
	public static void open(String url, String type) {
		
		Command.loadDriver();
		if(type.equals(Constants.CHROME)) {
			
			driver  = new ChromeDriver();
		}
		else
		if(type.equals(Constants.FIREFOX)) {
			driver = new FirefoxDriver();
		}
		
		driver.get(url);
		
	}
	
	public static void delay() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private static By getBy(String name, String type) {
		By by = null;
		if(type.equals(Type.ID)) {
		by = By.id(name);
		}
		else
		if(type.equals(Type.NAME)) {
			by = By.name(name);
		}
		else
		if(type.equals(Type.CLASS)) {
			by = By.className(name);
		}
		return by;
	}
	
	public static void type(String name, String type, String val ) {
		//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobiles");
		By by = getBy(name, type);
		WebElement element = driver.findElement(by);
		element.sendKeys(val);
		
	}
	
	public static void close() {
		if(driver!=null) {
			driver.close();
		}
	}
	
	

}
