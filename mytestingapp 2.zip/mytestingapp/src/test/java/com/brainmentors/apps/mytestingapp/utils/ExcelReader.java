package com.brainmentors.apps.mytestingapp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

public class ExcelReader {
	
	public static void main(String[] args) {
		try {
			Object[][] table = readXLS();
			for(int row =0; row<table.length; row++) {
				for(int col = 0; col<table[row].length; col++) {
					System.out.print(table[row][col]+" ");
				}
				System.out.println();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Object[][] readXLS() throws IOException {
		// For the Table (2-D Array)
		Object listOfRows[][] = new Object[ConfigReader.getRows()][];
		String path = ConfigReader.getValue(Constants.XLS_PATH);
		File file = new File(path);
		int currentRow = 0;
		
		if(!file.exists()) {
			System.out.println("XLS File is Missing!");
			System.exit(0);
			return null;
		}
		FileInputStream fs = new FileInputStream(file);
		
		HSSFWorkbook workBook = new HSSFWorkbook(fs);
		HSSFSheet sheet = workBook.getSheetAt(0);
		Iterator<Row> rows = sheet.rowIterator();
		boolean isFirstRowRead = false;
		while(rows.hasNext()) {
			Row row = rows.next(); // current row give and move to the next row
			// Skipping the First Row
			if(!isFirstRowRead) {
				isFirstRowRead = true;
				continue;
			}
			Iterator<Cell> cells = row.cellIterator();
			// Contain the Current Row
			Object rowData [] = new Object[ConfigReader.getCols()];
			int currentCol = 0;
			while(cells.hasNext()) {
				Cell cell =cells.next();
				if(cell.getCellType()== CellType.STRING) {
					String cellValue = cell.getStringCellValue();
					if(cellValue.startsWith("'")) {
						cellValue = cellValue.substring(1);
					}
					// Filling the cells in the current row
					rowData[currentCol] = cellValue;
					//System.out.print(cellValue+" ");
				}
				else
				if(cell.getCellType()==CellType.NUMERIC) {
					// Filling the cells in the current row
					rowData[currentCol] = cell.getNumericCellValue();
					//System.out.print("N "+cell.getNumericCellValue()+" ");
				}
				currentCol++;
			} // Cell Ends
			// Fill the rows in the table (2-D Array)
			listOfRows[currentRow] = rowData;
			currentRow++;
			//System.out.println();
		}
		workBook.close();
		fs.close();
		return listOfRows;
		
	}

}
