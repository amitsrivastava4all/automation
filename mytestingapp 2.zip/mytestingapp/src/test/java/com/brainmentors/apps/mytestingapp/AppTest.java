package com.brainmentors.apps.mytestingapp;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.brainmentors.apps.mytestingapp.utils.ConfigReader;
import com.brainmentors.apps.mytestingapp.utils.Constants;
import com.brainmentors.apps.mytestingapp.utils.ExcelReader;

public class AppTest{
	
	@DataProvider(name="mydata")
	public Object[][] getXLSData(){
		try {
			return ExcelReader.readXLS();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@Test(dataProvider = "mydata",threadPoolSize = 10,invocationCount = 10)
	public void testCaseForPHPTravelRegister(String firstName, String lastName, String mobile, String email, String password, String cpassword) {
		System.setProperty(ConfigReader.getValue(Constants.DRIVER_NAME)
				, ConfigReader.getValue(Constants.DRIVER_PATH));
		WebDriver driver = new ChromeDriver();
		
		driver.get(ConfigReader.getValue(Constants.URL));
		driver.manage().window().maximize();
		driver.findElement(By.name("firstname")).sendKeys(firstName);
		driver.findElement(By.name("lastname")).sendKeys(lastName);
		driver.findElement(By.name("phone")).sendKeys(mobile);
		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("confirmpassword")).sendKeys(cpassword);
		driver.findElement(By.className("btn-success")).submit();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.close();
	}
	
	@Test(enabled = false)
	public void testCaseForLogin() {
		String driverPath = "/Users/amit/Documents/seleniumdailycodews/chromedriver";
		String driverName = "webdriver.chrome.driver";
		System.setProperty(driverName, driverPath );
		WebDriver driver = new ChromeDriver();
		// Hit the URL in Chrome Browser
		driver.get("https://www.flipkart.com/");
		WebElement element = driver.findElement(By.partialLinkText("New to Flipkart"));
		element.click();
		//element = driver.findElement(By.className("_2IX_2-"));
		//driver.findElement(By.className("fjhsdjkfhgks-")).sendKeys("6534543");
		
				try {
			
		driver.findElement(By.className("_2IX_2-")).sendKeys("678678678");
		}
		catch(NoSuchElementException ee) {
			System.out.println("This element not found in this page");
		}
	}
	
}