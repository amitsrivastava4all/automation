package com.brainmentors.apps.mytestingapp.utils;
/**
 * Config Reader is used to read the config.properties file
 * @author amit
 *
 */

import java.util.ResourceBundle;

public interface ConfigReader {
	ResourceBundle rb = ResourceBundle.getBundle("config");
	public static String getValue(String key) {
		return rb.getString(key);
	}
	public static int getRows() {
		return Integer.parseInt(rb.getString("rows"));
	}
	public static int getCols() {
		return Integer.parseInt(rb.getString("cols"));
	}
}
