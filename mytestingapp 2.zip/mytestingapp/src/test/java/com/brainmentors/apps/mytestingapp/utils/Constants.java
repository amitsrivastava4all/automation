package com.brainmentors.apps.mytestingapp.utils;

public interface Constants {
	public static final String XLS_PATH = "xlspath";
	String DRIVER_PATH  = "driverpath";
	String DRIVER_NAME = "drivername";
	String URL = "url";

}
