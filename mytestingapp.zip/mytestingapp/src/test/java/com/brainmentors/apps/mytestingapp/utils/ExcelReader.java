package com.brainmentors.apps.mytestingapp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

public class ExcelReader {
	
	public static void main(String[] args) {
		try {
			readXLS();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void readXLS() throws IOException {
		String path = ConfigReader.getValue(Constants.XLS_PATH);
		File file = new File(path);
		if(!file.exists()) {
			System.out.println("XLS File is Missing!");
			return ;
		}
		FileInputStream fs = new FileInputStream(file);
		
		HSSFWorkbook workBook = new HSSFWorkbook(fs);
		HSSFSheet sheet = workBook.getSheetAt(0);
		Iterator<Row> rows = sheet.rowIterator();
		while(rows.hasNext()) {
			Row row = rows.next(); // current row give and move to the next row
			Iterator<Cell> cells = row.cellIterator();
			while(cells.hasNext()) {
				Cell cell =cells.next();
				if(cell.getCellType()== CellType.STRING) {
					String cellValue = cell.getStringCellValue();
					if(cellValue.startsWith("'")) {
						cellValue = cellValue.substring(1);
					}
					System.out.print(cellValue+" ");
				}
				else
				if(cell.getCellType()==CellType.NUMERIC) {
					System.out.print("N "+cell.getNumericCellValue()+" ");
				}
			}
			System.out.println();
		}
		workBook.close();
		fs.close();
		
	}

}
