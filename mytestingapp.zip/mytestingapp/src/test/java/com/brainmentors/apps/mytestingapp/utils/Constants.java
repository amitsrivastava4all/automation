package com.brainmentors.apps.mytestingapp.utils;

public interface Constants {
	public static final String XLS_PATH = "xlspath";

}
