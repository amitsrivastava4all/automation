package com.brainmentors.apps.mytestingapp;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class AppTest{
	
	@Test
	public void testCaseForLogin() {
		String driverPath = "/Users/amit/Documents/seleniumdailycodews/chromedriver";
		String driverName = "webdriver.chrome.driver";
		System.setProperty(driverName, driverPath );
		WebDriver driver = new ChromeDriver();
		// Hit the URL in Chrome Browser
		driver.get("https://www.flipkart.com/");
		WebElement element = driver.findElement(By.partialLinkText("New to Flipkart"));
		element.click();
		//element = driver.findElement(By.className("_2IX_2-"));
		//driver.findElement(By.className("fjhsdjkfhgks-")).sendKeys("6534543");
		
				try {
			
		driver.findElement(By.className("_2IX_2-")).sendKeys("678678678");
		}
		catch(NoSuchElementException ee) {
			System.out.println("This element not found in this page");
		}
	}
	
}