package com.brainmentors.lms.testing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.brainmentors.lms.utils.Driver;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = Driver.getChromeDriver();
		Driver.openURL(driver, "https://the-internet.herokuapp.com/javascript_alerts");
		List<WebElement> list = driver.findElements(By.tagName("button"));
		for(WebElement ele : list) {
			if(ele.getText().contains("Alert")) {
				ele.click();
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				break;
			}
		}
		
	}

}
