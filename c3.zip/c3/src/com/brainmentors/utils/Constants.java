package com.brainmentors.utils;

public interface Constants {
	// public static final String CHROME = "chrome";
	String CHROME = "chrome";
	String FIREFOX = "firefox";
	String SAFARI = "safari";
}
