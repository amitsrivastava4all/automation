package com.brainmentors.utils;

public interface Type {
	String ID = "id";
	String NAME = "name";
	String CLASS = "class";
	String TAG = "tag";
}
