package com.brainmentors.testing;

import com.brainmentors.utils.Command;
import com.brainmentors.utils.Type;

public class FourthDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Command.open(Command.getURL(), Command.getConfigBrowser());
		String result = Command.dropDownValues("selecttype", Type.ID);
		
		System.out.println(result);
		Command.click("radiobutton", Type.ID);
		Command.click("selected(1234)", Type.NAME);
		Command.dropDownSelect("selecttype", Type.ID, "Selenium RC");
		
		//Command.click("secondajaxbutton", Type.ID);
		Command.delay();
		String txt = Command.getText("html5div", Type.ID);
		 result = txt.contains("I have been added with a timeout")?"Test pass":"Test Fails";
		System.out.println("Result is "+result);
		Command.linkClick("Home Page");
		Command.delay();
		Command.close();
	}
	

}
