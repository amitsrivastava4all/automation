package com.brainmentors.testing;

import com.brainmentors.utils.Command;
import com.brainmentors.utils.ConfigReader;
import com.brainmentors.utils.Constants;
import com.brainmentors.utils.Type;

public class ThirdDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Command.open(Command.getURL(), Command.getConfigBrowser());
		//int count = Command.getCount("a", Type.TAG);
		int count = Command.getCount("img", Type.TAG);
		System.out.println("Count is "+count);
		Command.close();

	}

}
