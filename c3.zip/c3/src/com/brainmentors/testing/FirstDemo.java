package com.brainmentors.testing;



import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;

public class FirstDemo {

	public static void main(String[] args) {
		// Load a Driver
		// c:\\abcd\\xyz\\chromedriver.exe
		String driverPath = "/Users/amit/Documents/seleniumdailycodews/chromedriver";
		String driverName = "webdriver.chrome.driver";
		System.setProperty(driverName, driverPath );
		WebDriver driver = new ChromeDriver();
		// Hit the URL in Chrome Browser
		driver.get("https://www.flipkart.com/");
		WebElement element = driver.findElement(By.partialLinkText("New to Flipkart"));
		element.click();
		//element = driver.findElement(By.className("_2IX_2-"));
		//driver.findElement(By.className("fjhsdjkfhgks-")).sendKeys("6534543");
		
				try {
			
		driver.findElement(By.className("_2IX_2-")).sendKeys("678678678");
		}
		catch(NoSuchElementException ee) {
			System.out.println("This element not found in this page");
		}
		//		if(element!=null) {
//		element.sendKeys("5345435435");
//		}
//		else {
//			System.out.println("Element Not Found..");
//		}
		//driver.close();
		//driver.quit();
		

	}

}
