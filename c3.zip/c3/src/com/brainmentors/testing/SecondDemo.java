package com.brainmentors.testing;

import com.brainmentors.utils.Command;
import com.brainmentors.utils.Constants;
import com.brainmentors.utils.Type;

public class SecondDemo {
	
	public static void main(String[] args) {
		//Command.loadDriver();
		Command.open(Command.getURL(),
				Command.getConfigBrowser());
		Command.type("twotabsearchtextbox",
				Type.ID, "Mobiles");
		Command.delay();
		
		Command.close();
	}
	

}
